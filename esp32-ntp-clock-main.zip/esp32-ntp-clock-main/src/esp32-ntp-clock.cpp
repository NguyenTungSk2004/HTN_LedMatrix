#include<Arduino.h>
#include <WiFi.h>
#include<Wire.h>
#include <WiFiClientSecure.h>
#include<ArduinoJson.h>
const char *authorization = "0de5b3faa1e385d1ca4bc553b1f4c253";//place here your API key
const char *cityName = "Haiphong";
const char *host = "api.openweathermap.org";
const int httpsPort = 443;
int httpsClientTimeout = 5000; //in millis
WiFiClient client;
WiFiClientSecure httpsClient;
void setup() {
  Serial.begin(9600);
  Serial.print("Connecting to WiFi");
  WiFi.begin("Wokwi-GUEST", "", 6);
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }
  Serial.println(" Connected!");
  Serial.println(WiFi.localIP());

    httpsClient.setInsecure();
  httpsClient.setTimeout(httpsClientTimeout);
  delay(1000);
  int retry = 0;
  while( (!httpsClient.connect(host, httpsPort) ) && (retry <15) ){
    delay(100);
    Serial.print(".");
    retry++;
  }
  if(retry==15){ Serial.println("Connection failed"); }
  else{ Serial.println("Connected to Server"); }

  //Send the GET requst
  String req = String("GET /data/2.5/weather?q=")+cityName+"&appid="+authorization+
      " HTTP/1.1\r\n"+ 
      "Host: api.openweathermap.org\r\n"+
      "Connection: close\r\n"+
      "\r\n";
  Serial.println(req);
  httpsClient.print(req);

  // Put response into a string
  String payload = "";
  while (httpsClient.connected()) {
    String line = httpsClient.readStringUntil('\n');
    if (line == "\r") {
      Serial.println("headers received");
      break;
    }
  }
  while (httpsClient.available()) {
    char c = httpsClient.read();
    payload += c;
  }
  //Parse only "temp" and "humidity" from the JSON response
  StaticJsonDocument<200> doc;
  DeserializationError error = deserializeJson(doc, payload);
  if (error) {
    Serial.print(F("deserializeJson() failed: "));
    Serial.println(error.c_str());
    return;
  }
  int temp = (int)doc["main"]["temp"];
  int humidity = (int)doc["main"]["humidity"];
  Serial.println(cityName);
  Serial.print("Temperature: ");
  Serial.println(temp-273);
  Serial.print("Humidity: ");
  Serial.println(humidity);
  //Close the TCP connection
  httpsClient.stop();
  Serial.println();
  Serial.println("Connection closed");
    
}

void loop() {
  delay(100); // TODO: Build something amazing!
}